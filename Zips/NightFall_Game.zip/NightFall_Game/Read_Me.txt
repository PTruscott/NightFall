To play the game NightFall run NightFall.jar

DO NOT REMOVE THE .JAR FROM THE FOLDER

If this is done, none of the sound effects for the audiogame will work.  If needed, move the entire folder with the jar in it.

Controls:

W: Forward
A: Left
S: Backwards
D: Right
J: Rotate anti-clockwise
K: ROtate clockwise
SPACE: Fire
ESC: Quit to menu.