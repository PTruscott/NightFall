To play the game NightFall run NightFall.jar

DO NOT REMOVE THE .JAR FROM THE FOLDER

If this is done, none of the sound effects for the audiogame will work.  If needed, move the entire folder with the jar in it.

Controls:

W: Forward
A: Left
S: Backwards
D: Right
J: Rotate anti-clockwise
K: ROtate clockwise
G: Throw grenade
E: Quick Knife
SPACE: Fire
ESC: Quit to menu.

Numbers 1 through to 5 chooses a gun in menu.
NOTE: 4 is a shotgun, 5 is a rocket launcher.  Both of these are experimental, and/or OP/Broken.  Same with grenade/knife.  You only have two grenades or knife.

Gameplay:

W moves you in the direction you are facing.

The aim of the game is to kill as many enemies as possible.  
Different guns require different number of hits to kill an enemy.
When the enemy dies it respawns in a random location and moves at a slightly faster pace.
If it harms you it will teleport to a random location and keep the same pace.

A sound plays when:

Player takes damage.
You fire your gun.
You hit the enemy.
The enemy dies.
The enemy appears on your radar.

Radar:
If the enemy is within 50' either side of you, the radar will start beeping.
The higher pitch the sound the closer the enemy is to the center.
It will play through which ear you want to turn to, e.g. left ear, turn anti-clockwise.
The faster the beeps the closer the enemy is.



