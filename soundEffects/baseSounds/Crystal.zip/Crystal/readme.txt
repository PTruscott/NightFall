This zip archive contains two different versions of Crystal, one for use in 64 bit VST hosts, like SONAR and Cubase, and one for use in 32 bit hosts, like Abletone Live.
If you're not sure whether you have a 32 or 64 bit host, you're probably using 32 bit, but check the documentation for your host to be sure. To install VST plugins,
copy the .dll file to the plugin folder for your host. If you're not sure where that folder is, check the documentation for your host.
